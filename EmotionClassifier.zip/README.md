# Emotion Classifier

CLI tool to predict emotions in tweets.